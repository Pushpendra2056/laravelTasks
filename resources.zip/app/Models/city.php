<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class city extends Model
{
    use HasFactory, Notifiable;
    
    protected $table = 'city';
    protected $primaryKey = 'id';
    
    protected $fillable = [
        'state_id',
        'name',
    ];

    public function state()
    {
        return $this->belongsTo(state::class);
    }

    public function pincode()
    {
        return $this->hasMany(pincode::class);
    }
}
