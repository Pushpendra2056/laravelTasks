<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class state extends Model
{
    use HasFactory, Notifiable;

    protected $table = 'state';
    protected $primaryKey = 'id';

    protected $fillable = [
        'name',
    ];

    public function city()
    {
        return $this->hasMany(city::class);
    }
}
