<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\state;
use App\Models\city;
use App\Models\pincode;

use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function registerPage(){
        return view('register');
    }

    public function registerUserStore(Request $request){
        $validated = $request->validate([
            'name' => 'required',
            'number' => 'required|unique:users',
        ]);
        $user = User::create([
            'name' => $validated['name'],
            'number' => $validated['number'],
        ]);
        
        return redirect('/login');
    }

    public function loginPage(){
        return view('login');
    }

    public function loginByNumber(Request $request){
        $validated = $request->validate([
            'number' => 'required',
        ]);
        $otp = rand(10000, 99999);
        $user = User::where('number',$validated['number'])->first();
        if($user){
            $user->otp = $otp;
            if($user->save()){
                return response()->json([
                    'status'=> true,
                    'message'=> 'User Found!',
                    'otp' => $otp
                ]);
            }else{
                return response()->json([
                    'status'=> false,
                    'message'=> 'unable to store OTP!'
                ]);
            }
        }
        else{
            return response()->json([
                'status'=> false,
                'data'=> [],
                'message'=> 'User Not Found!'
            ]);
        }
    }

    public function verifyOTP(Request $request){
        $number = $request->number;
        $otp = $request->otp;
        $user = User::where('number',$number)->where('otp',$otp)->first();
        if($user){
            $user->otp = 00000;
            if($user->save()){
                Auth::login($user);
                return response()->json([
                    'status' => true,
                    'route' => '/dashboard',
                    'message' => 'SuccessFully Login! Please Wait',
                ]);
            }
        }else{
            return response()->json([
                'status' => false,
                'route' => '',
                'message' => 'Please Enter Valid OTP!'
            ]);
        }
    }


    public function dashboard(){
        return view('dashboard');
    }
    
    public function showStatePage(){
        $state = state::get();
        return view('state',compact('state'));
    }

    public function deleteState($id){
        state::where('id',$id)->delete();
        $city = city::where('state_id',$id)->get();
        foreach($city as $value){
            pincode::where('city_id',$value->id)->delete();
        }
        city::where('state_id',$id)->delete();

        return redirect()->back();
    }

    public function editState(Request $request){
        $state = state::where('id',$request->id)->first();
        $state->name = $request->state;
        $state->save();

        return redirect()->back();
    }

    public function addState(Request $request){
        state::create(['name'=>$request->stateName]);
        return redirect()->back();
    }

    public function showCityPage(){
        $city = city::with('state')->get();
        $allcity = city::get();
        $allstate = state::get();
        return view('city',compact('city','allcity','allstate'));
    }

    public function deleteCity($id){
        $city = city::where('id',$id)->get();
        foreach($city as $value){
            pincode::where('city_id',$value->id)->delete();
        }
        city::where('id',$id)->delete();

        return redirect()->back();
    }

    public function editCity(Request $request){
        $state = city::where('id',$request->id)->first();
        $state->state_id = $request->myStateSelect;
        $state->name = $request->cityName;
        $state->save();

        return redirect()->back();
    }

    public function addCity(Request $request){
        city::create(['state_id'=>$request->myStateID,'name'=>$request->citysName]);
        return redirect()->back();
    }

    public function showPincodePage(){
        $pincode = pincode::with('city')->get();
        $city = city::get();
        return view('pincode',compact('pincode','city'));
    }

    public function deletePincode($id){
        $city = pincode::where('id',$id)->delete();
        return redirect()->back();
    }

    public function editPincode(Request $request){
        $state = pincode::where('id',$request->id)->first();
        $state->city_id = $request->myCitySelect;
        $state->pincode = $request->pincode;
        $state->save();

        return redirect()->back();
    }

    public function addPincode(Request $request){
        pincode::create(['city_id'=>$request->myCityID,'pincode'=>$request->pincodes]);
        return redirect()->back();
    }
}
