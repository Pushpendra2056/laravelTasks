<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <form method="post">
       
        <div class="container">
            <div class="row m-4 p-5">
                <center class="h3">Login User Here</center>
                <div class="col-12 m-2">
                    <label>Phone Number:</label>
                    <input type="number" class="form-control" name="number" id="number">
                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 m-2 d-none otpclass">
                    <label>OTP:</label>
                    <input type="number" class="form-control" name="otp" id="otp">
                </div>
                <div class="col-12 m-2 d-none messageclass text-danger">

                </div>
                <div class="col-12 m-2">
                    <div class="btn btn-primary" id="login-submit">Login</div>
                </div>
                <div class="col-12 m-2">
                    <div class="btn btn-warning d-none" id="verify-submit">Verify OTP</div>
                </div>
            </div>
        </div>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
        $("#login-submit").on("click",function(){
            $.ajax({
                url: "<?php echo e(route('loginByNumber')); ?>",
                type: "post",
                data:{number : $("#number").val()},
                dataType: "json",
                success: function(result){
                    if(result.status == true){
                        $("#login-submit").addClass('d-none');
                        $("#verify-submit").removeClass('d-none');
                        $(".otpclass").removeClass('d-none');
                        $("#number").prop('disabled', true);
                        console.log(result.otp);
                    }else{
                        $("#login-submit").removeClass('d-none');
                        $("#verify-submit").addClass('d-none');
                        $(".otpclass").addClass('d-none');
                        $("#number").prop('disabled', false);
                    }
                }
            })
        })

        $("#verify-submit").on("click",function(){
            $.ajax({
                url: "<?php echo e(route('verifyOTP')); ?>",
                type: "post",
                data:{number : $("#number").val(), otp : $("#otp").val()},
                dataType: "json",
                success: function(result){
                    if(result.status == true){
                        window.location.href = result.route;
                    }else{
                        $(".messageclass").removeClass('d-none');
                        $(".messageclass").text(result.message);
                    }
                }
            })
        })

        
    </script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\details\resources\views/login.blade.php ENDPATH**/ ?>