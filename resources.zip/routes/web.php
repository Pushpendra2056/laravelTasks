<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Auth;
use App\Http\Middleware\authUserCheck;



    Route::get('/dashboard',[UserController::class,'dashboard'])->middleware('checkUser');

    Route::get('/show-state-page',[UserController::class,'showStatePage'])->middleware('checkUser');
    Route::get('/delete-state/{id}',[UserController::class,'deleteState'])->middleware('checkUser');
    Route::post('/editState',[UserController::class,'editState'])->middleware('checkUser');
    Route::post('/addState',[UserController::class,'addState'])->middleware('checkUser');

    Route::get('/show-city-page',[UserController::class,'showCityPage'])->middleware('checkUser');
    Route::get('/delete-city/{id}',[UserController::class,'deleteCity'])->middleware('checkUser');
    Route::post('/editCity',[UserController::class,'editCity'])->middleware('checkUser');
    Route::post('/addCity',[UserController::class,'addCity'])->middleware('checkUser');

    Route::get('/show-pincode-page',[UserController::class,'showPincodePage'])->middleware('checkUser');
    Route::get('/delete-pincode/{id}',[UserController::class,'deletePincode'])->middleware('checkUser');
    Route::post('/editPincode',[UserController::class,'editPincode'])->middleware('checkUser');
    Route::post('/addPincode',[UserController::class,'addPincode'])->middleware('checkUser');

    Route::get('register',[UserController::class,'registerPage']);
    Route::post('register',[UserController::class,'registerUserStore']);

    Route::get('login',[UserController::class,'loginPage'])->name('login');
    Route::post('loginByNumber',[UserController::class,'loginByNumber'])->name('loginByNumber');
    Route::post('verifyOTP',[UserController::class,'verifyOTP'])->name('verifyOTP');

    Route::get('/', [UserController::class,'registerPage']);
    Route::get('/logout', function () {
        Auth::logout();
        return redirect('/login');
    });


